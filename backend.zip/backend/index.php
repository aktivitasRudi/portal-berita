<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    body {
      min-height: 100vh;
      background-color: #f8f9fa;
    }

    /* Sidebar styling */
    .sidebar {
      height: 100vh;
      width: 250px;
      background-color: #1e212d;
      position: fixed;
      top: 0;
      left: 0;
      color: #fff;
      padding-top: 20px;
      transition: all 0.3s;
    }

    .sidebar h4 {
      text-align: center;
      color: #ffc107;
    }

    .sidebar a {
      color: #adb5bd;
      text-decoration: none;
      display: flex;
      align-items: center;
      padding: 10px 20px;
      font-size: 16px;
      transition: all 0.3s;
    }

    .sidebar a.active, .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }

    .sidebar a i {
      margin-right: 10px;
    }

    /* Main content styling */
    .content {
      margin-left: 250px;
      padding: 20px;
    }

    .navbar {
      background-color: #343a40;
      border-bottom: 2px solid #ffc107;
    }

    .navbar .navbar-brand {
      color: #ffc107 !important;
    }

    .btn-primary {
      background-color: #ffc107;
      border: none;
    }

    .btn-primary:hover {
      background-color: #e0a800;
    }

    .table thead {
      background-color: #343a40;
      color: #fff;
    }

    .footer {
      margin-top: 30px;
      text-align: center;
      color: #6c757d;
    }
  </style>
</head>
<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <h4>Admin Dashboard</h4>
    <a href="#" class="active"><i class="fas fa-home"></i> Dashboard</a>
    <a href="#"><i class="fas fa-images"></i> Carousel</a>
    <a href="#"><i class="fas fa-list"></i> Kategori</a>
    <a href="#"><i class="fas fa-newspaper"></i> Berita</a>
    <a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>

  <!-- Main Content -->
  <div class="content">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      </div>
    </nav>

    <!-- Dashboard Heading -->
    <div class="mt-4">
      <h2 class="mb-4">Kelola Carousel</h2>
      <a href="#" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Tambah Carousel</a>

      <!-- Table -->
      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>ID</th>
              <th>Image</th>
              <th>Title</th>
              <th>Description</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td><img src="https://picsum.photos/100" alt="Image" class="img-thumbnail" style="width: 100px;"></td>
              <td>Sample Title</td>
              <td>Sample Description</td>
              <td>
                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>
                <a href="#" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
              </td>
            </tr>
            <tr>
              <td>2</td>
              <td><img src="https://picsum.photos/100" alt="Image" class="img-thumbnail" style="width: 100px;"></td>
              <td>Another Title</td>
              <td>Another Description</td>
              <td>
                <a href="#" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> Edit</a>
                <a href="#" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Hapus</a>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Footer -->
  <footer class="footer">
    &copy; 2025 Admin Dashboard - All Rights Reserved
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
