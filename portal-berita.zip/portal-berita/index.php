<?php
    include"lib/koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Berita Detik Style</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="asset/css/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Portal Berita</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Berita</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Kontak</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

   <!-- Slider / Carousel -->
   <div id="newsCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="https://picsum.photos/1200/400?random=1" class="d-block w-100" alt="Slider Image 1">
            <div class="carousel-caption d-none d-md-block">
                <h5>Berita Terbaru 1</h5>
                <p>Informasi tentang perkembangan terbaru di dunia.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="https://picsum.photos/1200/400?random=2" class="d-block w-100" alt="Slider Image 2">
            <div class="carousel-caption d-none d-md-block">
                <h5>Berita Terbaru 2</h5>
                <p>Berita mengenai kejadian penting di sekitar kita.</p>
            </div>
        </div>
        <div class="carousel-item">
            <img src="https://picsum.photos/1200/400?random=3" class="d-block w-100" alt="Slider Image 3">
            <div class="carousel-caption d-none d-md-block">
                <h5>Berita Terbaru 3</h5>
                <p>Highlight kejadian yang sedang hangat dibicarakan.</p>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#newsCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#newsCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

    <!-- Headline Section -->
    <div class="container mt-4">
        <div class="headline">
            <div class="row">
                <div class="col-md-3">
                    <div class="card">
                        <img src="https://picsum.photos/400/300?random=1" class="card-img-top" alt="News">
                        <div class="card-body">
                            <p class="card-text">Orang Kaya Mah Beda, Moge Tetap Ada yang Beli Meski Pajak Naik</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="https://picsum.photos/400/300?random=2" class="card-img-top" alt="News">
                        <div class="card-body">
                            <p class="card-text">Momen Irish Bella Pulang Kampung ke Belgia, Semua Kumpul Bikin Tersenyum</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="https://picsum.photos/400/300?random=3" class="card-img-top" alt="News">
                        <div class="card-body">
                            <p class="card-text">Video: STY yang Legowo Dipecat dari Timnas Indonesia Meski Heran</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <img src="https://picsum.photos/400/300?random=4" class="card-img-top" alt="News">
                        <div class="card-body">
                            <p class="card-text">Ditikam di Rumah, Suami Kareena Kapoor Berhasil Lewati Masa Kritis</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container mt-4">
        <div class="row">
            <!-- Kategori Berita -->
            <div class="col-lg-4">
                <div class="popular-news">
                    <h2 class="mb-4">Kategori Berita</h2>
                    <ul>
                        <li><a href="#">Politik</a></li>
                        <li><a href="#">Ekonomi</a></li>
                        <li><a href="#">Olahraga</a></li>
                        <li><a href="#">Teknologi</a></li>
                        <li><a href="#">Hiburan</a></li>
                    </ul>
                </div>
            </div>

            <!-- Grid News -->
            <div class="col-lg-8">
                <h2 class="mb-4">Berita Lainnya</h2>
                <div class="row grid-news">
                    <div class="col-md-6">
                        <div class="card">
                            <img src="https://picsum.photos/400/300?random=10" class="card-img-top" alt="News 1">
                            <div class="card-body">
                                <h5 class="card-title">Judul Berita 1</h5>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <img src="https://picsum.photos/400/300?random=11" class="card-img-top" alt="News 2">
                            <div class="card-body">
                                <h5 class="card-title">Judul Berita 2</h5>
                                <p class="card-text">Integer posuere erat a ante venenatis dapibus posuere velit aliquet.</p>
                                <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <img src="https://picsum.photos/400/300?random=12" class="card-img-top" alt="News 3">
                            <div class="card-body">
                                <h5 class="card-title">Judul Berita 3</h5>
                                <p class="card-text">Nulla vitae elit libero, a pharetra augue.</p>
                                <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <img src="https://picsum.photos/400/300?random=13" class="card-img-top" alt="News 4">
                            <div class="card-body">
                                <h5 class="card-title">Judul Berita 4</h5>
                                <p class="card-text">Venenatis dapibus posuere velit aliquet.</p>
                                <a href="#" class="btn btn-primary">Baca Selengkapnya</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-4">
        <div class="container text-center">
            <p>&copy; 2025 Portal Berita. All Rights Reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
